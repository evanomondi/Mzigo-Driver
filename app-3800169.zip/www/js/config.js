/*Kartero App Configuration*/
var krms_driver_config ={	
	'ApiUrl':"https://errandsguy.com/control/api",						
	'DialogDefaultTitle':"Your Errands App",    
	'APIHasKey':"fe7709c6106629a1fc4dd32745a0f592",
	'debug': true
};